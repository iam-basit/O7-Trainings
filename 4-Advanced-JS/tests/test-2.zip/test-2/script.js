var namesList = []
function addBtn() {
  var names = document.getElementById('names').value
  console.log(names)
  for (i = 0; i <= 6; i++) {
    namesList.push = [names]
  }
}

function showBtn() {
  //   console.log(namesList[])
  var names = document.getElementById('names').value

  //   var enterdNames = getElementById('enterdNames')

  //   enterdNames.innerText = names
}
